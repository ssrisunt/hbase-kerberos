/**
 * Created by soumick on 7/31/16.
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.google.common.collect.Sets;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.InputStream;
import java.util.*;

public class HBaseOperations{
    public static void main(String[] args) {
        try {
            Properties prop = new Properties();
            String propFileName =
                    "/Users/soumick/IdeaProjects/HBaseOperations/src/main/resources/hbasetable.properties";

            InputStream inputStream = new FileInputStream(propFileName);

            if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }

            // get the property value and print it out
            String allCols = prop.getProperty("all");
            String[] allColsList = allCols.split("\\,");
            Set<String> allColsSet = new HashSet<>();
            for(String l : allColsList) {
                String k = l.split("\\:")[0];
                String v = l.split("\\:")[1];
                allColsSet.add(k + ":" + v);
            }

            String mustCols = prop.getProperty("must");
            String[] mustColsList = mustCols.split("\\,");
            Set<String> mustColsSet = new HashSet<>();
            for(String l : mustColsList) {
                String k = l.split("\\:")[0];
                String v = l.split("\\:")[1];
                mustColsSet.add(k + ":" + v);
            }

            Configuration conf = HBaseConfiguration.create();
            Connection connection = ConnectionFactory.createConnection(conf);
            conf.addResource("file:///Users/soumick/hbase-1.1.5/conf/hbase-site.xml");
            Table table = connection.getTable(TableName.valueOf("testhbasetable"));
            Scan s = new Scan();
            ResultScanner ss = table.getScanner(s);
            Set<String> hBaseColsSet = new HashSet<>();

            for (Result r : ss) {
                List<Cell> listCells = r.listCells();
                for (Cell cell : listCells) {
                    String tableCf = Bytes.toString(CellUtil.cloneFamily(cell));
                    String tableCol = Bytes.toString(CellUtil.cloneQualifier(cell));
                    hBaseColsSet.add(tableCf + ":" + tableCol);
                }
            }

            System.out.println("All Columns: " + allColsSet);
            System.out.println("Must Columns: " + mustColsSet);
            System.out.println("HBase Columns: " + hBaseColsSet);

            Sets.SetView<String> hBaseAllColsDiff = Sets.difference(hBaseColsSet, allColsSet);
            if(hBaseAllColsDiff.isEmpty()) {
                System.out.println("Test Passed - No columns wrongly written in HBase");
            } else {
                System.out.println("Test Failed!! Columns wrongly written in HBase: " + hBaseAllColsDiff);
            }

            Sets.SetView<String> hBaseMustColsDiff = Sets.difference(mustColsSet, hBaseColsSet);
            if(hBaseMustColsDiff.isEmpty()) {
                System.out.println("Test Passed - All must columns are resent in HBase table");
            } else {
                System.out.println("Test Failed!! Must columns not present in HBase: " + hBaseMustColsDiff);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

/*

//JobConf jobConf = new JobConf(HBaseOperations.class);
Configuration conf = HBaseConfiguration.create();
Connection connection = ConnectionFactory.createConnection(conf);
conf.addResource("file:///Users/soumick/hbase-1.1.5/conf/hbase-site.xml");
//conf.addResource("file:///usr/hdp/current/hbase-client/conf/hbase-site.xml");
//conf.set("hbase.zookeeper.quorum", "server1.dev.hsbc.com, server2.dev.hsbc.com");
//conf.set("zookeeper.znode.parent", "/hbase-unsecure");
//conf.setInt("hbase.zookeeper.property.clientPort", 2181);
//conf.set("hbase.master.port", "localhost:16000");
*/