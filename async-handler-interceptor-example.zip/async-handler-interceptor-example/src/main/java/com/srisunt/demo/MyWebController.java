
package com.srisunt.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.concurrent.Callable;

@Controller
public class MyWebController {
    @RequestMapping("/")
    @ResponseBody
    public Callable<String> handleTestRequest () {

        System.out.println(System.currentTimeMillis() + " controller#handler called. Thread: " +
                Thread.currentThread()
                        .getName());

        Callable<String> callable = new Callable<String>() {
            @Override
            public String call () throws Exception {
                System.out.println(System.currentTimeMillis() + " controller-callable#async task started. Thread: " +
                                                       Thread.currentThread()
                                                             .getName());
                Thread.sleep(300);
                System.out.println(System.currentTimeMillis()+" controller-callable#async task finished Thread:" +
                        Thread.currentThread()
                                .getName());
                return "async result";
            }
        };

        System.out.println(System.currentTimeMillis()+" controller#handler finished" +
                Thread.currentThread()
                        .getName());
        return callable;
    }
}